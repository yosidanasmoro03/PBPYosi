<?php
$conn = new mysqli("localhost","root","","praktikum5");
// try {
//     $conn = new mysqli("localhost","root","","praktikum5");
// } catch(mysqli_sql_exception) {
//     die("koneksi gagal");
// }

// if($conn) {
//     die("koneksi berhasil");
// }

function daftar($data) {
    global $conn;

    $username = strtolower(stripslashes($data["username"]));
    $password = mysqli_real_escape_string($conn, $data["password"]);
    $password2 = mysqli_real_escape_string($conn, $data["password2"]);

    // cek username sudah ada atau belum
    $result = mysqli_query($conn, "SELECT * FROM pengguna WHERE username = '$username'");

    if( mysqli_fetch_assoc($result) ) {
        echo "<script>
				alert('username sudah terdaftar!')
		      </script>";
        return false;
    }

   // enkripsi password
    $password = password_hash($password, PASSWORD_DEFAULT);

    // tambahkan userbaru ke database
    mysqli_query($conn, "INSERT INTO pengguna VALUES('', '$username', '$password')");

    return mysqli_affected_rows($conn);
}
?>
