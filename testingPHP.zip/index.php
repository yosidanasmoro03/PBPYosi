<?php
session_start();
require 'koneksi.php';

if( isset($_POST["login"]) ) {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $result = mysqli_query($conn, "SELECT * FROM pengguna WHERE username = '$username'");

    // cek username
    if( mysqli_num_rows($result) === 1 ) {

        // cek password
        $row = mysqli_fetch_assoc($result);
        if( password_verify($password, $row["password"])) {
            echo "<script> 
                alert('anda berhasil login');
            </script>";
            header("Location: menuutama.php");
            exit;
        }
    }
    echo "login gagal";
}
?>

<!DOCTYPE html>
<html>
    <head>
    <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f2f2f2;
    }

    .container {
      max-width: 400px;
      margin: 0 auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 5px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .container h1 {
      text-align: center;
      margin-bottom: 20px;
    }

    .form-group {
      margin-bottom: 15px;
    }

    .form-group label {
      display: block;
      font-weight: bold;
      margin-bottom: 5px;
    }

    .form-group input {
      width: 95%;
      padding: 10px;
      border-radius: 3px;
      border: 1px solid #ccc;
    }

    .form-group button {
      display: block;
      width: 101%;
      padding: 10px;
      background-color: #4CAF50;
      color: #fff;
      font-weight: bold;
      border: none;
      border-radius: 3px;
      cursor: pointer;
    }

    .form-group button:hover {
      background-color: #45a049;
    }

    .form-group a {
      display: block;
      text-align: center;
      margin-top: 10px;
    }
  </style>
        <title> Login </title>
</head>
<body>
  <div class="container">
    <h1>Login</h1>
    <form action="" method="post">
      <div class="form-group">
        <label for="username">Username:</label>
        <input type="text" name="username" id="username">
      </div>
      <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" name="password" id="password">
      </div>
      <div class="form-group">
        <button type="submit" name="login">Login</button>
      </div>
      <a href="registrasi.php">Belum punya akun? Klik disini</a>
    </form>
  </div>
</body>
</html>