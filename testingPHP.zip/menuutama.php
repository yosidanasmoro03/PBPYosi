<?php
require "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
  $newTask = $_POST['newTask'];
  $query = "INSERT INTO agenda (task) VALUES ('$newTask')";
  $result = mysqli_query($conn, $query);
  if (!$result) {
    die("Query failed: " . mysqli_error($conn));
  }
  
  header("Location: {$_SERVER['PHP_SELF']}");
  exit;
}

$tasks = query("SELECT * FROM agenda");

function query($query) {
  global $conn;
  $result = mysqli_query($conn, $query);
  $rows = [];
  while ($row = mysqli_fetch_assoc($result)) {
    $rows[] = $row;
  }
  return $rows;
}
?>

<!DOCTYPE html>
<html>
<head>

  <title>To-Do List</title>
</head>
<body>
  <div id="myDIV" class="header">
    <h2>My To Do List</h2>
    <form action="" method="POST">
      <input type="text" name="newTask" id="myInput" placeholder="Title..." />
      <button type="submit" name="add" class="addBtn">Add</button>
    </form>
  </div>

  <ul id="myUL">
  <?php foreach ($tasks as $row) : ?>
    <li id="datanya-<?= $row["id"] ?>" class="task-item">
      <?= $row["task"]; ?>
      <div class="actions">
        <a href="hapuslist.php?id=<?= $row["id"] ?>" class="delete">hapus</a>
        <a class="edit-link edit" data-id="<?= $row["id"] ?>">edit</a>
        <a data-kondisi="<?= $row["cekbox"] ?>" data-id="<?= $row["id"] ?>" class="dataselesai" href="">selesai</a>
      </div>
    </li>
  <?php endforeach; ?>
</ul>
<br>
<a href="logout.php" class="logout-link">Log Out</a>

  <script>
    let editLinks = document.querySelectorAll(".edit-link");
    editLinks.forEach(link => {
      link.addEventListener("click", function() {
        let person = prompt("Ubah listmu:", "nonton film");
        let id = this.dataset.id;
        window.location.href = `editlist.php?name=${person}&id=${id}`;
      });
    });

    try {
    let list = document.querySelectorAll(".dataselesai");

    list.forEach(item => {
      let id = item.dataset.id;
      let datanya = document.querySelector(`#datanya-${id}`);
      if (item.getAttribute('data-kondisi') == '1') {
        datanya.classList.add('crossed-out');
      }

      item.addEventListener('click', function(ev) {
        ev.preventDefault();
        let kondisi = item.getAttribute('data-kondisi');
        let id = item.dataset.id;
        let datanya = document.querySelector(`#datanya-${id}`);

        if (kondisi == '0') {
          window.location.href = `kondisi.php?kondisi=true&id=${id}`;
          datanya.classList.add('crossed-out');
          item.setAttribute('data-kondisi', '1');
        } else {
          window.location.href = `kondisi.php?kondisi=false&id=${id}`;
          datanya.classList.remove('crossed-out');
          item.setAttribute('data-kondisi', '0');
        }
      });
    });

    // Menambahkan event listener untuk mencoret kalimat
    let taskItems = document.querySelectorAll(".task-item");
    taskItems.forEach(item => {
      item.addEventListener('click', function() {
        item.classList.toggle('crossed-out');
      });
    });
  } catch (error) {
    alert("Terjadi kesalahan: " + error.message);
  }
  </script>
</body>
</html>
