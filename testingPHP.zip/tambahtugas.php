<?php
require 'koneksi.php';
if(isset($_POST['submit'])) {
    $data=$_POST['data'];
    $sql = "INSERT INTO agenda (id,task,cekbox) VALUES ('', '$data','0')";
    if (mysqli_query($connect, $sql)) {
        echo "Data berhasil ditambahkan";

    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($connect);
    }
    header("Location: menuutama.php");
}?>