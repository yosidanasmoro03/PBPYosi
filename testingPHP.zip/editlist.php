<?php
require 'koneksi.php';
// var_dump($_GET);
// die();
$id = $_GET['id'];
$task = $_GET['name'];
$sql="UPDATE agenda
SET task = '$task'
WHERE id = $id;";
mysqli_query($conn, $sql);
header("Location: menuutama.php");
?>
