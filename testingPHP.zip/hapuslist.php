<?php
require("koneksi.php");
$id = $_GET["id"];
mysqli_query($conn,"DELETE FROM agenda WHERE id=$id;");
header("location: menuutama.php" );
?>