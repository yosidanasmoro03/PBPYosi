<?php
require 'koneksi.php';
$id = $_GET['id'];
$kondisi = $_GET['cekbox'];
$sql="UPDATE agenda
SET cekbox = '$kondisi'
WHERE id = $id;";
mysqli_query($conn, $sql);
header("Location: menuutama.php");
?>